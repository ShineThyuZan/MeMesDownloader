package com.example.cocktailrecipe.data.vo

class IngredientVo(var ingredient: String,
                   var measure: String) {
}