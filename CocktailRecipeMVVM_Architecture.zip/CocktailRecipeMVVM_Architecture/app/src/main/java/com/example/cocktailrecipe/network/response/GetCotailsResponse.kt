package com.example.cocktailrecipe.network.response

import com.example.cocktailrecipe.data.vo.CocatailVos

class GetCotailsResponse {


    lateinit var cotailsResponse: CocatailVos

}